import java.awt.Graphics;

public class NewRectangle extends Shape{
	
	public NewRectangle(int x, int y, int width, int height) {
		super(x, y, width, height);
	}
	
	public NewRectangle() {} 

	@Override
	public int calculateArea() {
		return getWidth() * getHeight() ;
	}
	
	public void draw(Graphics g) {
		g.drawRect(getX(), getY(), getWidth(), getHeight());
	}	

}
