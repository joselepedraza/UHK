import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JToolBar;

public class DrawFrame extends JFrame implements ActionListener, MouseListener{
	
	private JPanel drawPanel;
	private ShapeList shapeList = new ShapeList();
	private Shape newShape;
	
	
	

	public DrawFrame() {
		setTitle("Draw application") ;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE) ; //Establecemos la operacion por defecto para cuando cierre la ventana, si no lo ponemos se cierra la ventana pero sigue corriendo el programa
	
		initToolBar() ; //Inicializamos la barra de herramientas 
		initDrawPanel() ;
		setSize(500,400) ; //Establecemos el tamaño de la ventana, si no va despues de initToolBar() la ventana modificará su tamaño	
	}

		
	private void initDrawPanel() {
		drawPanel = new JPanel();
		drawPanel.addMouseListener(this);
		add(drawPanel, BorderLayout.CENTER) ; //Añadimos el JPanel a la ventana situandolo en el centro
		
	}


	private void initToolBar() {
		JToolBar toolbar = new JToolBar() ; //Crea la instancia de la barra de tareas
		
		JButton button = new JButton("Click") ; //Creamos un boton
		button.addActionListener(this); //Añadimos el listener
		
		toolbar.add(button) ; //Ponemos el boton en la barra de tareas
		
		setLayout(new BorderLayout()) ; // Situamos el boton en la ventana 
		add(toolbar, BorderLayout.PAGE_START) ; //Añadimos a la ventana la barra de tareas
		
		pack() ; //Como que empaqueta todo y lo mete en el main
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		newShape = new NewRectangle();
		shapeList.addShape(newShape); //Añadimos el rectangulo a la lista para dibujar varios
	
		Shape rect = new NewRectangle() ;
		
		
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
	/*	if (newShape != null) {
			newShape.setX(e.getX());
			newShape.setY(e.getY());
			newShape.setWidth(100);
			newShape.setHeight(50);
			
			newShape.draw(drawPanel.getGraphics()); //Llamamos a dibujar
		}
		
		newShape = null ;*/
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mousePressed(MouseEvent e) {
		if(newShape != null) {
			newShape.setX(e.getX());
			newShape.setY(e.getY());
		}
		
	}


	@Override
	public void mouseReleased(MouseEvent e) {
		int width, height ;
		if(newShape != null) {
			if(e.getX() > newShape.getX() && e.getY() > newShape.getY()) {
				width = e.getX() - newShape.getX() ; 
				height = e.getY() - newShape.getY();
				newShape.setWidth(width);
				newShape.setHeight(height) ;
			}else if(e.getX() < newShape.getX() && e.getY() < newShape.getY()){
				width = newShape.getX() - e.getX() ;
				height =newShape.getY() - e.getY() ;
				
				newShape.setX(e.getX());
				newShape.setY(e.getY());
				
				newShape.setWidth(width);
				newShape.setHeight(height) ;
			}else if(e.getX() > newShape.getX() && e.getY() < newShape.getY()){
				width = e.getX() - newShape.getX() ; 
				height =newShape.getY() - e.getY() ;
				
				newShape.setY(e.getY());
				
				newShape.setWidth(width);
				newShape.setHeight(height) ;
			}else if(e.getX() < newShape.getX() && e.getY() > newShape.getY()){
				width = newShape.getX() - e.getX() ;
				height = e.getY() - newShape.getY();
				
				newShape.setX(e.getX());
				
				newShape.setWidth(width);
				newShape.setHeight(height) ;
			}
			newShape.draw(drawPanel.getGraphics());
			
		}
		
		newShape = null ;
	}
	public void paint(Graphics g) {
		super.paint(g);
		
		shapeList.draw(drawPanel.getGraphics()) ;
	}

	public static void main(String[] args) {
		new DrawFrame().setVisible(true);
		

	}






}
