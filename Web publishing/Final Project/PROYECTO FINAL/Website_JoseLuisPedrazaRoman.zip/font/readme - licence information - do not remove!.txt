EN >>> You've just downloaded Bohemian Typewriter font which is based on typeface of Czech Remagg typewriter.     

Bohemian Typewriter font was created by Lukas Krakora and is free for non-commercial use only!

If you want to use this font commercially, please contact me at: krraaa@yahoo.com to get the information about pricing.

Please type "Bohemian Typewriter" in subject of your message.

I will also appreciate to receive any comments or pictures of your artwork using this font at the same address.  

Please feel free to distribute the font, but keep this readme file with it and do not change the font in any way!

You can find my other fonts on www.typewriterfonts.net 

Have fun! 


CZ >>> Pr�v� jste si st�hli font Bohemian Typewriter, vytvo�en� dle p�sma �esk�ho psac�ho stroje Remagg.

Font Bohemian Typewriter byl vytvo�en Luk�em Kr�korou a je voln� ke sta�en� a pou�it� av�ak pouze pro nekomer�n� ��ely!

V p��pad� z�m�ru vyu��t font komer�n� m� pros�m kontaktujte na emailu: krraaa@yahoo.com a dohodneme se na cen� k oboustrann� spokojenosti.

Pokud mi budete ps�t, nezapome�te do p�edm�tu zpr�vy napsat "Bohemian Typewriter".

Ocen�m i va�e koment��e nebo obr�zky va�� tvorby s vyu�it�m m�ho fontu, kter� m��ete zas�lat na stejnou adresu.

Klidn� font d�le distribuujte, ale pouze spole�n� s t�mto textem! V ��dn�m p��pad� font nijak nem��te a neupravujte.

Me dalsi fonty naleznete na www.typewriterfonts.net

M�jte se fajn!
